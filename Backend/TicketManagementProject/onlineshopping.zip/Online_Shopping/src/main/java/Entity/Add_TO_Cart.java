package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Add_TO_Cart")
public class Add_TO_Cart {

	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
    @Column(name="userID")
		private int userID;
	   @Column(name="adminId")
		private int adminId;
		public Add_TO_Cart(int userID, int adminId) {
			super();
			this.userID = userID;
			this.adminId = adminId;
		}
		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}
		public int getAdminId() {
			return adminId;
		}
		public void setAdminId(int adminId) {
			this.adminId = adminId;
		}
		
		
		
		

	

}
