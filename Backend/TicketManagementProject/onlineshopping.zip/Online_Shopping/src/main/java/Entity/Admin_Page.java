package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Admin_page")
public class Admin_Page {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
    @Column(name="adminId")
	private int adminId;
	@Column(name="admin_name")
	private String admin_name;
	@Column(name="phoneNo")
	private long phoneNO;
	@Column(name="password")
	private String password;
	public Admin_Page(int adminId, String admin_name, long phoneNO, String password) {
		super();
		this.adminId = adminId;
		this.admin_name = admin_name;
		this.phoneNO = phoneNO;
		this.password = password;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public long getPhoneNO() {
		return phoneNO;
	}
	public void setPhoneNO(long phoneNO) {
		this.phoneNO = phoneNO;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
