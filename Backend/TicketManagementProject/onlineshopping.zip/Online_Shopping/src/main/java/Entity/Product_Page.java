package Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_page")
public class Product_Page {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
    @Column(name="product_name")
	private int product_name;
    @Column(name="description")
	private String description;
    @Column(name="quantity")
	private int quantity;
    @Column(name="price")
	private int price;
    @Column(name="product_Id")
    private int product_Id;
    
	public Product_Page(int product_name, String description, int quantity, int price ,int product_Id) {
		super();
		this.product_name = product_name;
		this.description = description;
		this.quantity = quantity;
		this.price = price;
		this.product_Id = product_Id;
		
	}
	public int getProduct_name() {
		return product_name;
	}
	public void setProduct_name(int product_name) {
		this.product_name = product_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDesciription(String desciription) {
		this.description = desciription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getproduct_Id() {
		return product_Id;
	}
	public void setproduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}
	
	

}
