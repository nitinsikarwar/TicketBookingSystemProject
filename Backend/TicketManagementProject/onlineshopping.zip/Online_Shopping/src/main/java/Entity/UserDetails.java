package Entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="User")
public class UserDetails {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY) 
	@Column(name="userID")
    private int userID;
	@Column(name="username")
    private String username;
	@Column(name="passeord")
    private String Password;
	@Column(name="MobileNo")
    private int MobileNO ;
    public String getUsername() {
	return username;
}
public UserDetails(String username, int userID, String password, int mobileNO) {
		super();
		this.username = username;
		this.userID = userID;
		Password = password;
		MobileNO = mobileNO;
	}
public void setUsername(String username) {
	this.username = username;
}
public int getUserID() {
	return userID;
}
public void setUserID(int userID) {
	this.userID = userID;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public int getMobileNO() {
	return MobileNO;
}
public void setMobileNO(int mobileNO) {
	MobileNO = mobileNO;
}
public List<UserDetails> findAll() {
	// TODO Auto-generated method stub
	return null;
}


	

}
