package persistance;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import Entity.Admin_Page;

public interface Admin_Repository extends JpaRepository<Admin_Page, Integer> {

@Query("form Admin_page where admin_name=?1 password=?2")
public List<Admin_Page> findByadmin_nameAndpassword(String admin_name,String password);



}