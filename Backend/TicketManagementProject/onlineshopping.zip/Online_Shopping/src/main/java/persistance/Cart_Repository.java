package persistance;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import Entity.Add_TO_Cart;
import Entity.UserDetails;

public interface Cart_Repository extends JpaRepository<Add_TO_Cart, Integer> {
	
	@Query("form Add_TO_Cart where userID=?1")	
	public List<Add_TO_Cart> findByuserID(int ID);
	
	

}
