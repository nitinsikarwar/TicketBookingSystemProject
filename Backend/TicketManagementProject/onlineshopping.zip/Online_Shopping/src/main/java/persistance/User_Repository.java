package persistance;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import Entity.UserDetails;

public interface User_Repository extends JpaRepository<UserDetails, Integer> {
	@Query("form User where username=?1 password=?2")
	public List<UserDetails> findByusernameAndpassword(String username,String password);


	

}
