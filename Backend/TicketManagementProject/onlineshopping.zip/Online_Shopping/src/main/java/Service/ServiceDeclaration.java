package Service;

import java.util.List;

import Entity.Add_TO_Cart;
import Entity.Admin_Page;
import Entity.Product_Page;
import Entity.UserDetails;

public interface ServiceDeclaration {
	
	
	
	public List<UserDetails> DisplayAllUserDetails();
	public UserDetails findByIdUserDetails(int id);
	public void InsertUserDetails(UserDetails UserDetails);
	public void UpdateUserDetails(UserDetails student);
	public String deleteUserDetails(int id);
	public List<UserDetails> findByUserNameAndPasswordUser(String username,String password);
	
	
	public List<Admin_Page> findAllAdmin_Page();
	public Admin_Page findByAdmin_Page(int id);
	public void InsertAdmin_Page(Admin_Page AdminDetails);
	public void UpdateAdmin_Page(Admin_Page AdminDetails);
	public String deleteAdminDetails(int AdminId);
	
	
	
	public List<Product_Page>findAllProduct_Page(int id);
	public UserDetails findByproduct_Id(int id);
	public void InsertProduct_Page(Product_Page ProductDetails);
	public void UpdateProduct_Page(Product_Page ProductDatails);
//	public 
	
	
//    public List<Add_TO_Cart>findAll
    
	
	

	
	
	
	
} 