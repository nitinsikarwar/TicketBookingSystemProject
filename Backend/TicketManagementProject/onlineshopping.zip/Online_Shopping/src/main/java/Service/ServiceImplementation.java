package Service;

import java.util.List;

import javax.transaction.Transactional;

import Entity.Add_TO_Cart;
import Entity.Admin_Page;
import Entity.Product_Page;
import Entity.UserDetails;



public class ServiceImplementation implements ServiceDeclaration {
	
	private UserDetails us;
	private Admin_Page ap;
	private Product_Page pp;
	private Add_TO_Cart ac;
	
	
	
	@Autowired
	
	public ServiceImplementation(UserDetails us, Admin_Page ap, Product_Page pp, Add_TO_Cart ac) {
		super();
		this.us = us;
		this.ap = ap;
		this.pp = pp;
		this.ac = ac;
	}

	@Override@Transactional
	public List<UserDetails> DisplayAllUserDetails() {
		// TODO Auto-generated method stub
		return us.findAll();
		
	}

	@Override@Transactional
	public UserDetails findByIdUserDetails(int id) {
		// TODO Auto-generated method stub
	   return us.findById(id).get();
	
	public void InsertUserDetails(UserDetails UserDetails) {
		// TODO Auto-generated method stub
		us.Save(UserDetails);
	}

	@Override@Transactional
	public void UpdateUserDetails(UserDetails student) {
		// TODO Auto-generated method stub
		
	}

	@Override@Transactional
	public String deleteUserDetails(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public List<UserDetails> findByUserNameAndPasswordUser(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public List<Admin_Page> findAllAdmin_Page() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public Admin_Page findByAdmin_Page(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public void InsertAdmin_Page(Admin_Page AdminDetails) {
		// TODO Auto-generated method stub
		
	}

	@Override@Transactional
	public void UpdateAdmin_Page(Admin_Page AdminDetails) {
		// TODO Auto-generated method stub
		
	}

	@Override@Transactional
	public String deleteAdminDetails(int AdminId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public List<Product_Page> findAllProduct_Page(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public UserDetails findByproduct_Id(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override@Transactional
	public void InsertProduct_Page(Product_Page ProductDetails) {
		// TODO Auto-generated method stub
		
	}

	@Override@Transactional
	public void UpdateProduct_Page(Product_Page ProductDatails) {
		// TODO Auto-generated method stub
		
	}
	
	
}
